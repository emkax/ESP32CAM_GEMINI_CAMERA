#include "esp_camera.h"
#include <SPI.h>

#define SPI_SCK   14
#define SPI_MISO  12
#define SPI_MOSI  13
#define SPI_SS    4

#define BUTTON_PIN 16   // Press button to take picture

SPIClass SPI_CAM(VSPI);

void setupCamera() {
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer   = LEDC_TIMER_0;
  config.pin_d0       = 5;
  config.pin_d1       = 18;
  config.pin_d2       = 19;
  config.pin_d3       = 21;
  config.pin_d4       = 36;
  config.pin_d5       = 39;
  config.pin_d6       = 34;
  config.pin_d7       = 35;
  config.pin_xclk     = 0;
  config.pin_pclk     = 22;
  config.pin_vsync    = 25;
  config.pin_href     = 23;
  config.pin_sccb_sda = 26;
  config.pin_sccb_scl = 27;
  config.pin_pwdn     = 32;
  config.pin_reset    = -1;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;
  config.frame_size   = FRAMESIZE_QVGA;
  config.jpeg_quality = 10;
  config.fb_count     = 1;

  if (esp_camera_init(&config) != ESP_OK) {
    Serial.println("Camera init failed");
    while (true);
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(BUTTON_PIN, INPUT_PULLUP);    // Button: LOW when pressed

  SPI_CAM.begin(SPI_SCK, SPI_MISO, SPI_MOSI, SPI_SS);
  pinMode(SPI_SS, OUTPUT);
  digitalWrite(SPI_SS, HIGH);

  setupCamera();

  Serial.println("ESP32-CAM Sender Ready");
}

void loop() {
  if (digitalRead(BUTTON_PIN) == LOW) {
    Serial.println("Button pressed → Capturing image…");
    delay(100); // debounce

    camera_fb_t* fb = esp_camera_fb_get();
    if (!fb) {
      Serial.println("Capture failed");
      return;
    }

    uint32_t len = fb->len;

    Serial.print("Sending image size: ");
    Serial.println(len);

    digitalWrite(SPI_SS, LOW);

    // send 4-byte header
    SPI_CAM.transfer((len >> 24) & 0xFF);
    SPI_CAM.transfer((len >> 16) & 0xFF);
    SPI_CAM.transfer((len >> 8) & 0xFF);
    SPI_CAM.transfer(len & 0xFF);

    // send image bytes
    for (uint32_t i = 0; i < len; i++) {
      SPI_CAM.transfer(fb->buf[i]);
    }

    digitalWrite(SPI_SS, HIGH);

    esp_camera_fb_return(fb);
    Serial.println("Image sent!");

    delay(300); // avoid sending too many repeats
  }
}
